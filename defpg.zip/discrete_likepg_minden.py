# %%
import gymnasium as gym
import torch
import potion.envs.cartpole

from potion.common.logger import Logger
from potion.actors.continuous_policies import ShallowGaussianPolicy, DeepGaussianPolicy
from potion.actors.discrete_policies import  DeepGibbsPolicy

from potion.algorithms.reinforce import reinforce

from potion.algorithms.vr_defensive import svrpg_def, pagepg_def, srvrpg_def, stormpg_def, srvrpg_def_onpol
from potion.algorithms.variance_reduced import svrpg, pagepg, srvrpg, stormpg

from potion.meta.steppers import ConstantStepper


seeds = [1000, 2000, 3000, 4000, 5000]
#algorithms = [svrpg, svrpg_def, stormpg, stormpg_def, pagepg, pagepg_def, srvrpg, srvrpg_def]

algorithms = [svrpg, svrpg_def, stormpg, stormpg_def, pagepg, pagepg_def, srvrpg, srvrpg_def, reinforce]
ssizes = [1e-4, 3e-4, 4e-5, 4e-4, 5e-5, 5e-4, 1e-6, 3e-6, 1e-4]



#stormpg_def: 4e-4
#stormpg: 4e-5
#svrpg: 1e-4
#svrpg_def: 3e-4
#pagepg: 5e-5
#pagepg_def: 5e-4
#srvrpg: 1e-6
#srvrpg_def: 3e-6
#reinforce: 1e-4



for algo, stp in  zip(algorithms, ssizes): 

    try:
        for seed in seeds:
            #env = potion.envs.cartpole.ContCartPole()
            env = gym.make('CartPole-v1')
            state_dim = sum(env.observation_space.shape) #dimensionality of the state space
            #action_dim = sum(env.action_space.shape) #dimensionality of the action space
            action_dim = env.action_space.n
            horizon = 200 #maximum length of a trajectory
            gamma = 0.9999 #discount factor #amit plottoltam ott 0.95 volt
            """
            policy = DeepGaussianPolicy(state_dim, #input size
                                        action_dim, #output size
                                        mu_init = None, #torch.zeros((2, 32)), #initial mean parameters
                                        hidden_neurons=[32,],
                                        logstd_init = 0., #log of standard deviation
                                        learn_std = True #We are NOT going to learn the variance parameter
                                        ) 
            """
            policy = DeepGibbsPolicy(state_dim=state_dim, n_actions=action_dim, hidden_neurons=[32, 32], bias=True)
            state = torch.ones(state_dim)
            policy.act(state)
            #print(policy.get_flat())
            stepper = ConstantStepper(stp)
            batchsize = 10#100
            log_dir = '../logs_disccartpole_v/'
            log_name = algo.__name__ + '_seed' + str(seed)
            logger = Logger(directory=log_dir, name = log_name)
            #seed = 42
            if hasattr(env, 'seed'):
                env.seed(seed)
            #policy.set_from_flat(torch.zeros(32*32*2+1)) #Reset the policy (in case is run multiple times)


            if algo.__name__ == 'reinforce':
                reinforce(  env = env,
                            policy = policy,
                            horizon = horizon,
                            stepper = stepper,
                            batchsize = batchsize,
                            #init_batchsize = 16,
                            #mini_batchsize = 8,
                            disc = gamma,
                            iterations = 3000,
                            seed = seed,
                            logger = logger,
                            save_params = 5, #Policy parameters will be saved on disk each 5 iterations
                            shallow = False, #Use optimized code for shallow policies
                            estimator = 'gpomdp', #Use the G(PO)MDP refined estimator
                            baseline = 'avg', #Use Peter's variance-minimizing baseline
                )

            elif algo.__name__ == 'pagepg_def' or algo.__name__=="pagepg":
                algo (env = env,
                        policy = policy,
                        horizon = horizon,
                        stepper = stepper,
                        #batchsize = batchsize,
                        init_batchsize = 100,
                        mini_batchsize = 5,
                        #epoch_length = 10,
                        disc = gamma,
                        iterations = 3000,
                        seed = seed,
                        logger = logger,
                        save_params = 5, #Policy parameters will be saved on disk each 5 iterations
                        shallow = False, #Use optimized code for shallow policies
                        estimator = 'gpomdp', #Use the G(PO)MDP refined estimator
                        baseline = 'avg', #Use Peter's variance-minimizing baseline
                        snapshot_prob=0.8,
                    )
                
            elif algo.__name__ == "stormpg_def" or algo.__name__ == "stormpg":
                algo (env = env,
                        policy = policy,
                        horizon = horizon,
                        stepper = stepper,
                        #batchsize = batchsize,
                        init_batchsize = 100,
                        mini_batchsize = 5,
                        #epoch_length = 10,
                        disc = gamma,
                        iterations = 3000,
                        seed = seed,
                        logger = logger,
                        save_params = 5, #Policy parameters will be saved on disk each 5 iterations
                        shallow = False, #Use optimized code for shallow policies
                        estimator = 'gpomdp', #Use the G(PO)MDP refined estimator
                        baseline = 'avg', #Use Peter's variance-minimizing baseline
                        decay = 0.99
                    )
            else:
                algo (env = env,
                    policy = policy,
                    horizon = horizon,
                    stepper = stepper,
                    #batchsize = batchsize,
                    init_batchsize = 100,
                    mini_batchsize = 5,
                    #epoch_length = 10,
                    disc = gamma,
                    iterations = 3000,
                    seed = seed,
                    logger = logger,
                    save_params = 5, #Policy parameters will be saved on disk each 5 iterations
                    shallow = False, #Use optimized code for shallow policies
                    estimator = 'gpomdp', #Use the G(PO)MDP refined estimator
                    baseline = 'avg' #Use Peter's variance-minimizing baseline
                    
                )
    except:
        print("Error in " + algo.__name__ + " with step size " + str(stp))
        continue


# %%
