#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jan 16 15:00:16 2019

@author: matteo
"""

from gymnasium.envs.registration import register
from gymnasium import spaces

register(
    id='LQG1D-v0',
    entry_point='potion.envs.lqg1d:LQG1D'
)

register(
    id='lqr1d-v0',
    entry_point='potion.envs.lqr1d:lqr1d'
)

register(
    id='LQ-v0',
    entry_point='potion.envs.lq:LQ'
)

register(
    id='mass-v0',
    entry_point='potion.envs.mass:mass'
)

register(
    id='drone-v0',
    entry_point='potion.envs.drone:drone'
)

register(
    id='crash-v0',
    entry_point='potion.envs.crash:crash'
)

register(
    id='ContCartPole-v0',
    entry_point='potion.envs.cartpole:ContCartPole'
)

register(
    id='GridWorld-v0',
    entry_point='potion.envs.gridworld:GridWorld'
)

register(
    id='Corridor-v0',
    entry_point='potion.envs.corridor:Corridor'
)

register(
    id='MiniGolf-v0',
    entry_point='potion.envs.minigolf:MiniGolf'
)

register(
    id='ComplexMiniGolf-v0',
    entry_point='potion.envs.minigolf:ComplexMiniGolf'
)
