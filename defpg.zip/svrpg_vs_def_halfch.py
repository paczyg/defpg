# %%
import gymnasium as gym
import torch
import potion.envs.cartpole

from potion.common.logger import Logger
from potion.actors.continuous_policies import ShallowGaussianPolicy, DeepGaussianPolicy
from potion.actors.discrete_policies import  DeepGibbsPolicy

from potion.algorithms.reinforce import reinforce

from potion.algorithms.vr_defensive import svrpg_def, pagepg_def, srvrpg_def, stormpg_def, srvrpg_def_onpol
from potion.algorithms.variance_reduced import svrpg, pagepg, srvrpg, stormpg

from potion.meta.steppers import ConstantStepper


seeds = [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000,9000, 10000]
#algorithms = [svrpg, svrpg_def, stormpg, stormpg_def, pagepg, pagepg_def, srvrpg, srvrpg_def]
#ssizes = [0.00005, 0.00005, 0.00005, 0.00005, 0.000005, 0.000005, 0.00005, 0.00005]

#algorithms = [pagepg, pagepg_def]
#ssizes = [0.000005, 0.00005]

algorithms = [pagepg, pagepg_def]
ssizes = [0.00000005, 0.0000005]

#stormpg_def: 0.00005
#stormpg: 0.00005
#svrpg: 0.00005
#svrpg_def: 0.00005
#pagepg: 0.000005
#pagepg_def: 0.000005
#srvrpg: 0.00005
#srvrpg_def: 0.00005



for algo, stp in  zip(algorithms, ssizes): 
    for seed in seeds:
        #env = potion.envs.cartpole.ContCartPole()
        env = gym.make('HalfCheetah-v4')
        state_dim = sum(env.observation_space.shape) #dimensionality of the state space
        action_dim = sum(env.action_space.shape) #dimensionality of the action space
        horizon = 300 #maximum length of a trajectory
        gamma = 0.9999 #discount factor #amit plottoltam ott 0.95 volt
        policy = DeepGaussianPolicy(state_dim, #input size
                                    action_dim, #output size
                                    mu_init = None, #torch.zeros((2, 32)), #initial mean parameters
                                    hidden_neurons=[32, 32],
                                    logstd_init = 0., #log of standard deviation
                                    learn_std = True #We are NOT going to learn the variance parameter
                                    ) 
        state = torch.ones(state_dim)
        policy.act(state)
        print(policy.get_flat())
        stepper = ConstantStepper(stp)
        batchsize = 10#100
        log_dir = '../logs_halfcheetah'
        log_name = algo.__name__ + '_seed' + str(seed)
        logger = Logger(directory=log_dir, name = log_name)
        #seed = 42
        if hasattr(env, 'seed'):
            env.seed(seed)
        #policy.set_from_flat(torch.zeros(32*32*2+1)) #Reset the policy (in case is run multiple times)


        if algo.__name__ == 'reinforce':
            reinforce(  env = env,
                        policy = policy,
                        horizon = horizon,
                        stepper = stepper,
                        batchsize = batchsize,
                        #init_batchsize = 16,
                        #mini_batchsize = 8,
                        disc = gamma,
                        iterations = 3000,
                        seed = seed,
                        logger = logger,
                        save_params = 5, #Policy parameters will be saved on disk each 5 iterations
                        shallow = False, #Use optimized code for shallow policies
                        estimator = 'gpomdp', #Use the G(PO)MDP refined estimator
                        baseline = 'avg', #Use Peter's variance-minimizing baseline
            )
        else:
            algo (env = env,
                policy = policy,
                horizon = horizon,
                stepper = stepper,
                #batchsize = batchsize,
                #init_batchsize = 16,
                #mini_batchsize = 8,
                disc = gamma,
                iterations = 3000,
                seed = seed,
                logger = logger,
                save_params = 5, #Policy parameters will be saved on disk each 5 iterations
                shallow = False, #Use optimized code for shallow policies
                estimator = 'gpomdp', #Use the G(PO)MDP refined estimator
                baseline = 'avg', #Use Peter's variance-minimizing baseline
            )


# %%
